package com.example.grad_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
