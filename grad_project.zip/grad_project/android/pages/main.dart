// import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_switch/flutter_switch.dart';
import 'package:toggle_switch/toggle_switch.dart';
// import 'first.dart';
// import 'second.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // routes:{
      //   '/firstpage'=(context)=>Firstpage(),
      // },
      home: Scaffold(
        backgroundColor: Colors.white,
        body: Center (
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              const SizedBox(
                height: 30,
                width: 500,
              ),
              SizedBox(
                height: 400,
                width: 400,
                child: Image.asset('assets/images/B1.jpg',
                scale: 1.7,
                  ),
                ),
              SizedBox(
                height: 90,
                width: 500,
                child: Column(
                  children: [
                    Text("Hello!",
                    textAlign: TextAlign.center,
                    style: TextStyle(

                      color: Colors.teal[500],
                      fontSize:40,
                  ),),
                   const Text("Equilibrium Maintainer",
                    style: TextStyle(
                      fontSize:20,))
                  ]
              ),
              ),
              const SizedBox(
                height: 5,
                width: 500,
              ),

              SizedBox(
                height: 50,
                width: 200,
                child: ToggleSwitch(
                minHeight: 10.0,
                minWidth: 99.0,
                cornerRadius: 20.0,
                activeBgColors: [[Colors.teal[300]!], [Colors.teal[300]!]],
                activeFgColor: Colors.white,
                inactiveBgColor: Colors.grey[300],
                inactiveFgColor: Colors.grey[500],
                initialLabelIndex: 0,
                totalSwitches: 2,
                labels: const ['doctor', 'patient'],
                radiusStyle: true,
                onToggle: (index) {
                  // print('switched to: $index');
                },
                ),
              ),
              SizedBox(
                height: 80,
                width: 500,
                child: Text('.',
                  textAlign: TextAlign.center,

                  style: TextStyle(
                      color: Colors.teal[500],
                      fontSize:70,)
                ,)
              ),

            ]
              ),
          ),
          ),
    );
  }
  }