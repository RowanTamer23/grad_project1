// import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
void main() {
  runApp(const Secondpage());
}
class Secondpage extends StatelessWidget {
  const Secondpage({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,

      home: Scaffold(
        backgroundColor: Colors.teal[300],

        body: SingleChildScrollView(
            child: Column(
              children:[
                const SizedBox (
                  height:163,
                  child: Row (
                    children:[
                    Column (
                      children: [
                        SizedBox (
                          height:50,),
                        Row (
                            children: [
                              SizedBox(
                                  width:30
                              ),
                              Text('Welcome!',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize:40,)
                              ,),
                              SizedBox(
                                width:120
                            ),
                              Icon(
                              Icons.apps,
                              size: 30,
                              color: Colors.white,
                            ),
                            // onPressed: (){
                            //
                            // }, )]
                          ]),
                        Text('log in to follow your exercises',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize:15,)),
                        SizedBox (
                          height:0,), ]),]),),

                Container (
                  height: 620,
                  width:500,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.vertical(top:Radius.circular(20)),
                    color: Colors.white, ),
                  child: Column ( children:[
                    const SizedBox(
                      height:70,
                    ),
                    Container(
                        height: 500,
                        width: 400,
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.vertical(top:Radius.circular(60), bottom: Radius.circular(60)),
                            color: Colors.white70,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                offset:  Offset(
                                  0.0,
                                  0.0,
                                ),
                                blurRadius: 5.0,
                                spreadRadius: -5.0,
                              ),
                              BoxShadow(
                                color: Colors.white,
                                offset:  Offset(-10.0, -10.0),
                                blurRadius: 1.0,
                                spreadRadius: -10.0,

                              ),
                              //BoxShadow
                            ]),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize:MainAxisSize.min ,
                          children: [

                            Container(
                              decoration: const BoxDecoration(
                                  borderRadius: BorderRadius.vertical(top:Radius.circular(60), bottom: Radius.circular(60)),
                                  color: Colors.white24,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey,
                                      offset:  Offset(
                                        -3.0,
                                        0.0,
                                      ),
                                      blurRadius: 5.0,
                                      spreadRadius: -5.0,
                                    ),
                                    BoxShadow(
                                      color: Colors.white,
                                      offset:  Offset(-10.0, -10.0),
                                      blurRadius: 1.0,
                                      spreadRadius: -5.0,

                                    ),
                                    //BoxShadow
                                  ]),
                              width: 250,
                              height:85,
                              child: Row( mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    const SizedBox(
                                      width: 15,),
                                    const Icon(
                                    Icons.person,
                                    size: 30,
                                    color: Colors.teal,
                                  ),
                                  const SizedBox(
                                  width: 15,),
                                    SizedBox(
                                      width: 150,
                                        height: 200,
                                        child: TextFormField(
                                      style: const TextStyle(fontSize: 15, color: Colors.black)  ,
                                      decoration: const InputDecoration(
                                          labelText: 'Email ID',
                                        labelStyle: TextStyle(fontSize: 18, color: Colors.teal)
                                      ),
                                      // onPressed: (){},child: const Text('Control angle', style: TextStyle(fontSize: 20))),
                                    ),)
                                    ]), ),

                            Container(
                              decoration: const BoxDecoration(
                                  borderRadius: BorderRadius.vertical(top:Radius.circular(60), bottom: Radius.circular(60)),
                                  color: Colors.white24,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey,
                                      offset:  Offset(
                                        -3.0,
                                        0.0,
                                      ),
                                      blurRadius: 5.0,
                                      spreadRadius: -5.0,
                                    ),
                                    BoxShadow(
                                      color: Colors.white,
                                      offset:  Offset(-10.0, -10.0),
                                      blurRadius: 1.0,
                                      spreadRadius: -5.0,

                                    ),
                                    //BoxShadow
                                  ]),
                              width: 250,
                              height: 85,
                              child:const Row( mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                     SizedBox(
                                      width: 15,),
                                     Icon(
                                      Icons.lock,
                                      size: 30,
                                      color: Colors.teal,
                                    ),
                                     SizedBox(
                                      width: 15,),
                                    SizedBox(
                                      width: 150,
                                      height: 200,
                                      child: TextField(
                                        obscureText: true,
                                        obscuringCharacter: "*",
                                        style:  TextStyle(fontSize: 15, color: Colors.black)  ,
                                        decoration:  InputDecoration(
                                            labelText: 'Password',
                                            labelStyle: TextStyle(fontSize: 18, color: Colors.teal)
                                        ),
                                        // onPressed: (){},child: const Text('Control angle', style: TextStyle(fontSize: 20))),
                                      ),)
                                  ]), ),

                            Container(
                              decoration: const BoxDecoration(
                                  borderRadius: BorderRadius.vertical(top:Radius.circular(60), bottom: Radius.circular(60)),
                                  color: Colors.white24,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey,
                                      offset:  Offset(
                                        -3.0,
                                        0.0,
                                      ),
                                      blurRadius: 5.0,
                                      spreadRadius: -5.0,
                                    ),
                                    BoxShadow(
                                      color: Colors.white,
                                      offset:  Offset(-10.0, -10.0),
                                      blurRadius: 1.0,
                                      spreadRadius: -5.0,

                                    ),
                                    //BoxShadow
                                  ]),
                              width: 250,
                              height: 85,
                              child:const Row( mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                     SizedBox(
                                      width: 15,),
                                     Icon(
                                      Icons.face,
                                      size: 30,
                                      color: Colors.teal,
                                    ),
                                     SizedBox(
                                      width: 15,),
                                    SizedBox(
                                      width: 150,
                                      height: 200,
                                      child: TextField(
                                        style:  TextStyle(fontSize: 15, color: Colors.black)  ,
                                        decoration:  InputDecoration(
                                            labelText: 'Name',
                                            labelStyle: TextStyle(fontSize: 18, color: Colors.teal)
                                        ),
                                        // onPressed: (){},child: const Text('Control angle', style: TextStyle(fontSize: 20))),
                                      ),)
                                  ]), ),
                            const SizedBox(
                              width: 100,
                            height: 30,),
                            SizedBox(
                                width: 340,
                                child: Row( mainAxisAlignment: MainAxisAlignment.start,
                                    children:[
                                      const Icon(
                                      Icons.check_box,
                                      size: 20,
                                      color: Colors.teal,
                                    ),
                                  TextButton(style:TextButton.styleFrom(
                                    foregroundColor: Colors.grey),
                                    onPressed: (){},child: const Text('Remember me', style: TextStyle(fontSize: 15))),
                              const SizedBox(
                                  width: 50,),
                                      TextButton(style:TextButton.styleFrom(
                                      foregroundColor: Colors.grey),
                                      onPressed: (){},child: const Text('forgot password?', style: TextStyle(fontSize: 15)))
                               ]),),

                            SizedBox(
                              width: 150,
                            child: TextButton(style:TextButton.styleFrom(
                              backgroundColor: Colors.teal,
                                foregroundColor: Colors.white),
                                onPressed: (){},child: const Text('Login', style: TextStyle(fontSize: 20))),
                            )
                          ],
                        )
                    ),
                  ], ),
                ),
            ])
        ),
      ),
    );
  }
}