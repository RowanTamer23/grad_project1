import 'package:flutter/material.dart';
import 'package:toggle_switch/toggle_switch.dart';
import 'first.dart';
import 'second.dart';
import 'seventh.dart';
import 'third.dart';
import 'fourth.dart';
import "package:all_bluetooth/all_bluetooth.dart";



void main() {
  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => const MyApp(),
      'first': (context) => const Firstpage(),
      '/second': (context) => const Secondpage(),
      '/third': (context) => const Thirdpage(),
      '/fourth': (context) => const Fourthpage(),


    },
  ));

}

// connection class

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => MyAppState(); }

class MyAppState extends State <MyApp> {
  final allBluetooth = AllBluetooth();

  final bondedDevices = ValueNotifier(<BluetoothDevice>[]);
  @override
  // void initState(){
    // super.initState();
    // Future.wait([
    //   permission.bluetooth.request(),
    //   permission.bluetoothConnect.request()
    // ]);
  // }
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return StreamBuilder(
        stream: allBluetooth.streamBluetoothState,
        builder: (context, snapshot){
      final bluetoothOn = snapshot.data ?? false;

      return StreamBuilder(
          stream: allBluetooth.listenForConnection,
          builder: (context, snapshot){
            final result = snapshot.data;
            print (result);

    return MaterialApp(
      debugShowCheckedModeBanner: false,


      home: Scaffold(

        backgroundColor: Colors.white,
        body: SingleChildScrollView (
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              const SizedBox(
                height: 30,
                width: 500,
              ),
              SizedBox(
                height: 400,
                width: 400,
                child: Image.asset('assets/images/B1.jpg',
                scale: 1.7,
                  ),
                ),
              SizedBox(
                height: 90,
                width: 500,
                child: Column(
                  children: [
                    Text("Hello!",
                    textAlign: TextAlign.center,
                    style: TextStyle(

                      color: Colors.teal[500],
                      fontSize:40,
                  ),),
                   const Text("Equilibrium Maintainer",
                    style: TextStyle(
                      fontSize:20,))
                  ]
              ),
              ),
              const SizedBox(
                height: 5,
                width: 500,
              ),

              SizedBox(
                height: 50,
                width: 200,
                child: ToggleSwitch(
                minHeight: 10.0,
                minWidth: 99.0,
                cornerRadius: 20.0,
                activeBgColors: [[Colors.teal[300]!], [Colors.teal[300]!]],
                activeFgColor: Colors.white,
                inactiveBgColor: Colors.grey[300],
                inactiveFgColor: Colors.grey[500],
                initialLabelIndex: 0,
                labels: const ['doctor', 'patient'],
                radiusStyle: true,
                onToggle: (index) {
                  if (index == 0 ){
                   Future.delayed(const Duration(seconds: 50));
                  Navigator.push( context, MaterialPageRoute(builder: (context) => const Secondpage()),);
                  }
                  else {Future.delayed(const Duration(seconds: 50));
                    Navigator.push( context, MaterialPageRoute(builder: (context) => const Seventhpage()),);}}
                      ),),
              const SizedBox(
                height: 50,
                width: 150,
              ),
              SizedBox(

                height: 60,
                width: 150,
                child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.vertical(top:Radius.circular(60), bottom: Radius.circular(60)),
                        color: Colors.white24,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey,
                            offset:  Offset(
                              -2.0,
                              0.0,
                            ),
                            blurRadius: 3.0,
                            spreadRadius: -5.0,
                          ),
                          BoxShadow(
                            color: Colors.teal,
                            offset:  Offset(-1.0, -3.0),
                            blurRadius: 3.0,
                            spreadRadius: -5.0,

                          ),
                          //BoxShadow
                        ]),
                    width: 100,
                    height: 50,
                    child: Row( mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 100,
                            child: TextButton(style:TextButton.styleFrom(
                                foregroundColor: Colors.white),
                                onPressed: switch(bluetoothOn){
                              false => null,
                                true => () async {
                                final devices = await allBluetooth.getBondedDevices();
                                bondedDevices.value = devices;
                                },
                                },
                                child: const Text('connect', style: TextStyle(fontSize: 20))),),
                    ValueListenableBuilder(valueListenable: bondedDevices,
                        builder: (context, devices,child){
                    return Expanded(child: ListView.builder(
                            itemCount: bondedDevices.value.length,
                            itemBuilder: (context, index) {
                            final device = devices[index];
                            return ListTile(
                              title: Text(device.name),
                              subtitle: Text(device.address),
                              onTap: (){
                                allBluetooth.connectToDevice(device.address);}
                            );
                          },
                          ));})
                          ]
                    )),
              ),

            ]
              ),
          ),
          ),
    );
  });
  });}}