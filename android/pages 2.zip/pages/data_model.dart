class DataModel {
  final String title;
  final String text;

  DataModel({
    required this.title,
    required this.text,
  });
}